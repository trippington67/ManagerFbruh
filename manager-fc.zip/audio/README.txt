CROWD SOUNDS

Manager FC already has a real stadium crowd (the background atmosphere) built into index.html, so nothing here is needed.
You can swap the sounds for your own recordings by putting files in this folder with these exact names
(the extension can be .mp3, .mp4, .m4a, .ogg or .wav):

  crowd.mp3   the looping stadium atmosphere under the whole match. 30 seconds or more works best.
  goal.mp3    applause for a goal you score away from home, or on neutral ground (4 to 8 seconds)
  cheer.mp3   a short cheer for chances and good moments (2 to 5 seconds)
  groan.mp3   a groan or sigh for a goal against or a near miss (1 to 3 seconds)

Any file you leave out keeps the built-in sound. After you change the files, redeploy the folder and reload the game.
