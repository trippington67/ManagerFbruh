import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);

// api.src.mjs
import crypto from "node:crypto";

// vendor/runtime-utils/lib/base64.ts
var getString = (input) => typeof input === "string" ? input : JSON.stringify(input);
var base64Decode = globalThis.Buffer ? (input) => Buffer.from(input, "base64").toString() : (input) => atob(input);
var base64Encode = globalThis.Buffer ? (input) => Buffer.from(getString(input)).toString("base64") : (input) => btoa(getString(input));

// vendor/runtime-utils/lib/environment.ts
var getEnvironment = () => {
  const { Deno, Netlify, process } = globalThis;
  return Netlify?.env ?? Deno?.env ?? {
    delete: (key) => delete process?.env[key],
    get: (key) => process?.env[key],
    has: (key) => Boolean(process?.env[key]),
    set: (key, value) => {
      if (process?.env) {
        process.env[key] = value;
      }
    },
    toObject: () => process?.env ?? {}
  };
};

// vendor/blobs/environment.ts
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};

// vendor/blobs/consistency.ts
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};

// vendor/blobs/metadata.ts
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header?.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response) => {
  if (!response.headers) {
    return {};
  }
  const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};

// vendor/blobs/region.ts
var REGION_AUTO = "auto";
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};

// vendor/shims/otel.mjs
var span = { setAttributes() {
}, setAttribute() {
}, setStatus() {
}, recordException() {
}, addEvent() {
}, end() {
}, isRecording() {
  return false;
} };
var getTracer = () => null;
var withActiveSpan = (_tracer, _name, fn) => fn(span);

// vendor/blobs/headers.ts
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";

// vendor/blobs/util.ts
var DEPLOY_STORE_PREFIX = "deploy:";
var SITE_STORE_PREFIX = "site:";
var isDeniedWrite = (res, { method, storeName }) => (res.status === 401 || res.status === 403) && (method === "put" || method === "delete") && storeName !== void 0 && !storeName.startsWith(DEPLOY_STORE_PREFIX);
var blobsErrorMessage = (res, context, responseBody) => {
  let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
  if (res.headers.has(NF_REQUEST_ID)) {
    details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
  }
  if (isDeniedWrite(res, context)) {
    const storeName = context.storeName?.startsWith(SITE_STORE_PREFIX) ? context.storeName.slice(SITE_STORE_PREFIX.length) : context.storeName;
    const summary = `Netlify Blobs could not write to store '${storeName}' (${details}).`;
    if (context.edgeAccess) {
      return summary;
    }
    return `${summary} Builds and build plugins can only write to deploy-specific stores: use 'getDeployStore' instead of 'getStore', or pass a 'token' with write access to the store. If this code is not running in a build, check that the token and site ID are valid. See https://docs.netlify.com/build/data-and-storage/netlify-blobs/#deploy-specific-stores`;
  }
  let message = `Netlify Blobs has generated an internal error (${details})`;
  if (!res.headers.get(NF_ERROR) && responseBody) {
    message += `: ${responseBody}`;
  }
  return message;
};
var BlobsInternalError = class extends Error {
  responseBody;
  status;
  constructor(res, context = {}, responseBody) {
    super(blobsErrorMessage(res, context, responseBody));
    this.name = "BlobsInternalError";
    this.status = res.status;
    this.responseBody = responseBody;
  }
};
var createBlobsInternalError = async (res, context = {}) => {
  const responseBody = await res.clone().text().catch(() => void 0);
  return new BlobsInternalError(res, context, responseBody);
};
var discardBody = async (res) => {
  await res.body?.cancel().catch(() => {
  });
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
function withSpan(span2, name, fn) {
  if (span2) return fn(span2);
  return withActiveSpan(getTracer(), name, (span3) => {
    return fn(span3);
  });
}

// vendor/blobs/retry.ts
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch, url, options, attemptsLeft = MAX_RETRY, getRetryUrl) => {
  try {
    const res = await fetch(url, options);
    const isRetryable = res.status === 429 || res.status >= 500 || getRetryUrl !== void 0 && res.status === 403;
    if (attemptsLeft > 0 && isRetryable) {
      await discardBody(res);
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      const retryUrl = getRetryUrl ? await getRetryUrl() : url;
      return fetchAndRetry(fetch, retryUrl, options, attemptsLeft - 1, getRetryUrl);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    const retryUrl = getRetryUrl ? await getRetryUrl() : url;
    return fetchAndRetry(fetch, retryUrl, options, attemptsLeft - 1, getRetryUrl);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});

// vendor/blobs/client.ts
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  apiURL;
  consistency;
  edgeURL;
  fetch;
  region;
  siteID;
  token;
  uncachedEdgeURL;
  /**
   * Whether requests reach Blobs through the edge rather than the API. Only
   * runtime environments are given an edge URL.
   */
  get edgeAccess() {
    return this.edgeURL !== void 0;
  }
  constructor({ apiURL, consistency, edgeURL, fetch, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" /* HEAD */ || method === "delete" /* DELETE */) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw await createBlobsInternalError(res, { edgeAccess: this.edgeAccess, method, storeName });
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    conditions = {},
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put" /* PUT */) {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    if ("onlyIfMatch" in conditions && conditions.onlyIfMatch) {
      headers["if-match"] = conditions.onlyIfMatch;
    } else if ("onlyIfNew" in conditions && conditions.onlyIfNew) {
      headers["if-none-match"] = "*";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    const usesSignedUrl = !this.edgeURL && key !== void 0 && storeName !== void 0 && method !== "head" /* HEAD */ && method !== "delete" /* DELETE */;
    let getRetryUrl;
    if (usesSignedUrl) {
      getRetryUrl = async () => {
        const finalRequest = await this.getFinalRequest({ consistency, key, metadata, method, parameters, storeName });
        return finalRequest.url;
      };
    }
    return fetchAndRetry(this.fetch, url, options, void 0, getRetryUrl);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// vendor/blobs/store.ts
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var STATUS_OK = 200;
var STATUS_PRE_CONDITION_FAILED = 412;
var STATUS_CONFLICT = 409;
var Store = class _Store {
  client;
  name;
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete" /* DELETE */, storeName: this.name });
    await discardBody(res);
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res, {
        edgeAccess: this.client.edgeAccess,
        method: "delete" /* DELETE */,
        storeName: this.name
      });
    }
  }
  async deleteAll() {
    let totalDeletedBlobs = 0;
    let hasMore = true;
    while (hasMore) {
      const res = await this.client.makeRequest({ method: "delete" /* DELETE */, storeName: this.name });
      if (res.status !== 200) {
        await discardBody(res);
        throw new BlobsInternalError(res, {
          edgeAccess: this.client.edgeAccess,
          method: "delete" /* DELETE */,
          storeName: this.name
        });
      }
      const data = await res.json();
      if (typeof data.blobs_deleted !== "number") {
        throw new BlobsInternalError(res);
      }
      totalDeletedBlobs += data.blobs_deleted;
      hasMore = typeof data.has_more === "boolean" && data.has_more;
    }
    return {
      deletedBlobs: totalDeletedBlobs
    };
  }
  async get(key, options) {
    return withSpan(options?.span, "blobs.get", async (span2) => {
      const { consistency, type } = options ?? {};
      span2?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.type": type,
        "blobs.method": "GET",
        "blobs.consistency": consistency
      });
      const res = await this.client.makeRequest({
        consistency,
        key,
        method: "get" /* GET */,
        storeName: this.name
      });
      span2?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        await discardBody(res);
        return null;
      }
      if (res.status !== 200) {
        await discardBody(res);
        throw new BlobsInternalError(res);
      }
      if (type === void 0 || type === "text") {
        return res.text();
      }
      if (type === "arrayBuffer") {
        return res.arrayBuffer();
      }
      if (type === "blob") {
        return res.blob();
      }
      if (type === "json") {
        return res.json();
      }
      if (type === "stream") {
        return res.body;
      }
      await discardBody(res);
      throw new BlobsInternalError(res);
    });
  }
  async getMetadata(key, options = {}) {
    return withSpan(options?.span, "blobs.getMetadata", async (span2) => {
      span2?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "HEAD",
        "blobs.consistency": options.consistency
      });
      const res = await this.client.makeRequest({
        consistency: options.consistency,
        key,
        method: "head" /* HEAD */,
        storeName: this.name
      });
      span2?.setAttributes({
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        throw new BlobsInternalError(res);
      }
      const etag = res?.headers.get("etag") ?? void 0;
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag,
        metadata
      };
      return result;
    });
  }
  async getWithMetadata(key, options) {
    return withSpan(options?.span, "blobs.getWithMetadata", async (span2) => {
      const { consistency, etag: requestETag, type } = options ?? {};
      const headers = requestETag ? { "if-none-match": requestETag } : void 0;
      span2?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "GET",
        "blobs.consistency": options?.consistency,
        "blobs.type": type,
        "blobs.request.etag": requestETag
      });
      const res = await this.client.makeRequest({
        consistency,
        headers,
        key,
        method: "get" /* GET */,
        storeName: this.name
      });
      const responseETag = res?.headers.get("etag") ?? void 0;
      span2?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.etag": responseETag,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        await discardBody(res);
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        await discardBody(res);
        throw new BlobsInternalError(res);
      }
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag: responseETag,
        metadata
      };
      if (res.status === 304 && requestETag) {
        return { data: null, ...result };
      }
      if (type === void 0 || type === "text") {
        return { data: await res.text(), ...result };
      }
      if (type === "arrayBuffer") {
        return { data: await res.arrayBuffer(), ...result };
      }
      if (type === "blob") {
        return { data: await res.blob(), ...result };
      }
      if (type === "json") {
        return { data: await res.json(), ...result };
      }
      if (type === "stream") {
        return { data: res.body, ...result };
      }
      await discardBody(res);
      throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
    });
  }
  list(options = {}) {
    return withSpan(options.span, "blobs.list", (span2) => {
      span2?.setAttributes({
        "blobs.store": this.name,
        "blobs.method": "GET",
        "blobs.list.paginate": options.paginate ?? false
      });
      const iterator = this.getListIterator(options);
      if (options.paginate) {
        return iterator;
      }
      return collectIterator(iterator).then(
        (items) => items.reduce(
          (acc, item) => ({
            blobs: [...acc.blobs, ...item.blobs],
            directories: [...acc.directories, ...item.directories]
          }),
          { blobs: [], directories: [] }
        )
      );
    });
  }
  async set(key, data, options = {}) {
    return withSpan(options.span, "blobs.set", async (span2) => {
      span2?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.size": typeof data == "string" ? data.length : data instanceof Blob ? data.size : data.byteLength,
        "blobs.data.type": typeof data == "string" ? "string" : data instanceof Blob ? "blob" : "arrayBuffer",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const res = await this.client.makeRequest({
        conditions,
        body: data,
        key,
        metadata: options.metadata,
        method: "put" /* PUT */,
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span2?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        if (res.status === STATUS_PRE_CONDITION_FAILED || res.status === STATUS_CONFLICT) {
          await discardBody(res);
          return { modified: false };
        }
        if (res.ok) {
          await discardBody(res);
          return { etag, modified: true };
        }
        throw await createBlobsInternalError(res, {
          edgeAccess: this.client.edgeAccess,
          method: "put" /* PUT */,
          storeName: this.name
        });
      }
      if (res.status === STATUS_OK) {
        await discardBody(res);
        return {
          etag,
          modified: true
        };
      }
      throw await createBlobsInternalError(res, {
        edgeAccess: this.client.edgeAccess,
        method: "put" /* PUT */,
        storeName: this.name
      });
    });
  }
  async setJSON(key, data, options = {}) {
    return withSpan(options.span, "blobs.setJSON", async (span2) => {
      span2?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.type": "json",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const payload = JSON.stringify(data);
      const headers = {
        "content-type": "application/json"
      };
      const res = await this.client.makeRequest({
        conditions,
        body: payload,
        headers,
        key,
        metadata: options.metadata,
        method: "put" /* PUT */,
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span2?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        if (res.status === STATUS_PRE_CONDITION_FAILED || res.status === STATUS_CONFLICT) {
          await discardBody(res);
          return { modified: false };
        }
        if (res.ok) {
          await discardBody(res);
          return { etag, modified: true };
        }
        throw await createBlobsInternalError(res, {
          edgeAccess: this.client.edgeAccess,
          method: "put" /* PUT */,
          storeName: this.name
        });
      }
      if (res.status === STATUS_OK) {
        await discardBody(res);
        return {
          etag,
          modified: true
        };
      }
      throw await createBlobsInternalError(res, {
        edgeAccess: this.client.edgeAccess,
        method: "put" /* PUT */,
        storeName: this.name
      });
    });
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static getConditions(options) {
    if ("onlyIfMatch" in options && "onlyIfNew" in options) {
      throw new Error(
        `The 'onlyIfMatch' and 'onlyIfNew' options are mutually exclusive. Using 'onlyIfMatch' will make the write succeed only if there is an entry for the key with the given content, while 'onlyIfNew' will make the write succeed only if there is no entry for the key.`
      );
    }
    if ("onlyIfMatch" in options && options.onlyIfMatch) {
      if (typeof options.onlyIfMatch !== "string") {
        throw new Error(`The 'onlyIfMatch' property expects a string representing an ETag.`);
      }
      return {
        onlyIfMatch: options.onlyIfMatch
      };
    }
    if ("onlyIfNew" in options && options.onlyIfNew) {
      if (typeof options.onlyIfNew !== "boolean") {
        throw new Error(
          `The 'onlyIfNew' property expects a boolean indicating whether the write should fail if an entry for the key already exists.`
        );
      }
      return {
        onlyIfNew: true
      };
    }
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            return withSpan(options?.span, "blobs.list.next", async (span2) => {
              span2?.setAttributes({
                "blobs.store": storeName,
                "blobs.method": "GET",
                "blobs.list.paginate": options?.paginate ?? false,
                "blobs.list.done": done,
                "blobs.list.cursor": currentCursor ?? void 0
              });
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get" /* GET */,
                parameters: nextParameters,
                storeName
              });
              span2?.setAttributes({
                "blobs.response.status": res.status
              });
              let blobs = [];
              let directories = [];
              if (![200, 204, 404].includes(res.status)) {
                await discardBody(res);
                throw new BlobsInternalError(res);
              }
              if (res.status === 404) {
                await discardBody(res);
                done = true;
              } else {
                const page = await res.json();
                if (page.next_cursor) {
                  currentCursor = page.next_cursor;
                } else {
                  done = true;
                }
                blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                directories = page.directories ?? [];
              }
              return {
                done: false,
                value: {
                  blobs,
                  directories
                }
              };
            });
          }
        };
      }
    };
  }
};

// vendor/blobs/store_factory.ts
var getDeployStoreRegion = (clientOptions, context) => {
  if (clientOptions.region) {
    return clientOptions.region;
  }
  if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
    if (!context.primaryRegion) {
      throw new Error(
        "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the store options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
      );
    }
    return context.primaryRegion;
  }
  return REGION_AUTO;
};
var getStore = (input, options) => {
  if (typeof input === "string") {
    const contextOverride = options?.siteID && options?.token ? { siteID: options?.siteID, token: options?.token } : void 0;
    const clientOptions = getClientOptions(options ?? {}, contextOverride);
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const contextOverride = input?.siteID && input?.token ? { siteID: input?.siteID, token: input?.token } : void 0;
    const clientOptions = getClientOptions(input, contextOverride);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const context = getEnvironmentContext();
    const clientOptions = getClientOptions(input, context);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    clientOptions.region = getDeployStoreRegion(clientOptions, context);
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// api.src.mjs
var V = 1;
var DAY = 864e5;
var TOKEN_LIFE = 60 * DAY;
var OFFER_LIFE = 7 * DAY;
var MAX_FRIENDS = 100;
var MAX_PENDING = 40;
var MAX_OUT = 6;
var MAX_IN = 25;
var MAX_CARDS = 700;
var MAX_SIDE = 4;
var MAIL_MAX = 60;
var HIST_MAX = 30;
var GONE_MAX = 600;
var _S = null;
function S() {
  if (_S) return _S;
  const ctx = getEnvironmentContext(), strong = !ctx.edgeURL || !!ctx.uncachedEdgeURL;
  const mk = (n) => getStore(strong ? { name: n, consistency: "strong" } : { name: n });
  return _S = { users: mk("mfc-users"), rows: mk("mfc-rows"), soc: mk("mfc-social"), trd: mk("mfc-trades"), own: mk("mfc-own"), meta: mk("mfc-meta") };
}
var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
async function getDoc(st, key) {
  const r = await st.getWithMetadata(key, { type: "json" });
  return r ? { v: r.data, etag: r.etag } : null;
}
var val = async (st, key) => {
  const d = await getDoc(st, key);
  return d ? d.v : null;
};
async function upd(st, key, fn, init) {
  for (let i = 0; i < 14; i++) {
    const d = await getDoc(st, key), cur = d ? d.v : init ? init() : null, nxt = fn(cur);
    if (nxt === void 0) return cur;
    const w = d ? await st.setJSON(key, nxt, { onlyIfMatch: d.etag }) : await st.setJSON(key, nxt, { onlyIfNew: true });
    if (w.modified) return nxt;
    await sleep2(12 + Math.random() * 45);
  }
  throw new Err("busy", "The server is busy. Try again in a moment.", 503);
}
var Err = class extends Error {
  constructor(code, msg, status) {
    super(msg || code);
    this.code = code;
    this.status = status || 400;
  }
};
var J = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
var NUM = (v, lo, hi, d = 0) => {
  v = Math.round(+v);
  return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d;
};
var STR = (v, m) => String(v == null ? "" : v).replace(/[\u0000-\u001f<>]/g, "").slice(0, m);
var HEX = (c, f) => typeof c === "string" && /^#[0-9a-f]{6}$/i.test(c) ? c : f;
var UID = (u) => typeof u === "string" && /^[A-Za-z0-9_-]{6,24}$/.test(u);
function cleanCard(o, mx = 130) {
  if (!o || typeof o !== "object") return null;
  const ovr = NUM(o.ovr, 1, mx, 50), c = {
    pid: o.pid == null ? null : NUM(o.pid, 0, 99999999),
    first: STR(o.first, 24),
    last: STR(o.last, 28) || "?",
    nat: STR(o.nat, 5),
    pos: /^[A-Z]{2,3}$/.test(o.pos) ? o.pos : "CM",
    ovr,
    age: NUM(o.age, 15, 50, 25),
    club: STR(o.club, 8),
    icon: !!o.icon,
    st: Array.isArray(o.st) && o.st.length === 6 ? o.st.map((v) => NUM(v, 0, mx + 70, ovr)) : Array(6).fill(ovr),
    pot: NUM(o.pot, 0, 9),
    ct: NUM(o.ct, 0, 99, 3),
    ctLen: NUM(o.ctLen, 0, 99, 3)
  };
  if (o.base != null) c.base = NUM(o.base, 1, 130, ovr);
  if (o.ed) c.ed = STR(o.ed, 10);
  if (o.win) c.win = typeof o.win === "object" ? JSON.stringify(o.win).length < 300 ? o.win : null : STR(o.win, 30);
  if (o.yr) c.yr = NUM(o.yr, 0, 2100);
  if (o.dev) c.dev = STR(o.dev, 12);
  if (o.u != null) {
    if (!UID(o.u)) return null;
    c.u = o.u;
  }
  return c;
}
var cleanCrest = (o) => {
  o = o && typeof o === "object" ? o : {};
  const r = { a: HEX(o.a, "#ecbb3f"), b: HEX(o.b, "#25324a"), pat: NUM(o.pat, 0, 60), shape: NUM(o.shape, 0, 30), emb: NUM(o.emb, 0, 60), nd: NUM(o.nd, 0, 9) };
  ["c", "ec", "p2c"].forEach((k) => {
    r[k] = o[k] ? HEX(o[k], null) : null;
  });
  r.p2 = o.p2 == null ? null : NUM(o.p2, 0, 60);
  r.es = o.es == null ? null : NUM(o.es, 0, 60);
  return r;
};
var BAD = ["fuck", "shit", "nigg", "cunt", "bitch", "rape", "nazi", "hitler", "whore", "slut", "fagg", "admin", "mfc_", "moderator"];
var nameOk = (n) => typeof n === "string" && /^[A-Za-z0-9_]{3,16}$/.test(n);
var lower = (n) => String(n).toLowerCase();
var scrypt = (pw, salt) => new Promise((res, rej) => crypto.scrypt(pw, salt, 32, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (e, k) => e ? rej(e) : res(k.toString("hex"))));
var eq = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
var b64u = (s) => Buffer.from(s).toString("base64url");
var _sec = null;
async function secret() {
  if (_sec) return _sec;
  const { meta } = S();
  let d = await getDoc(meta, "secret");
  if (!d) {
    await meta.setJSON("secret", { k: crypto.randomBytes(32).toString("hex") }, { onlyIfNew: true });
    d = await getDoc(meta, "secret");
  }
  return _sec = Buffer.from(d.v.k, "hex");
}
async function mkToken(u) {
  const body = b64u(JSON.stringify({ i: u.id, e: Date.now() + TOKEN_LIFE, v: u.tv | 0 }));
  return body + "." + crypto.createHmac("sha256", await secret()).update(body).digest("base64url");
}
async function authUser(token) {
  if (typeof token !== "string" || token.length > 400 || token.indexOf(".") < 0) throw new Err("auth", "Please sign in again.", 401);
  const [body, sig] = token.split("."), want = crypto.createHmac("sha256", await secret()).update(body).digest("base64url");
  if (!eq(sig, want)) throw new Err("auth", "Please sign in again.", 401);
  let p;
  try {
    p = JSON.parse(Buffer.from(body, "base64url").toString());
  } catch (e) {
    throw new Err("auth", "Please sign in again.", 401);
  }
  if (!p || p.e < Date.now()) throw new Err("auth", "Your session ended. Please sign in again.", 401);
  const u = await val(S().users, "u:" + p.i);
  if (!u || (u.tv | 0) !== (p.v | 0)) throw new Err("auth", "Please sign in again.", 401);
  return u;
}
var pub = (u) => ({ id: u.id, name: u.name, joined: u.joined });
var rid = () => crypto.randomBytes(8).toString("hex");
var emptySoc = () => ({ f: [], i: [], o: [] });
var emptyX = () => ({ i: [], o: [], lk: {}, h: [] });
var getSoc = (id) => val(S().soc, "f:" + id).then((v) => v || emptySoc());
var getX = (id) => val(S().trd, "x:" + id).then((v) => v || emptyX());
var addTo = (arr, v, max) => {
  if (!arr.includes(v)) arr.push(v);
  while (arr.length > max) arr.shift();
  return arr;
};
var dropFrom = (arr, v) => {
  const i = arr.indexOf(v);
  if (i >= 0) arr.splice(i, 1);
  return arr;
};
var mailAdd = (id, item) => upd(S().soc, "m:" + id, (m) => {
  m = m || { items: [] };
  m.items.push(Object.assign({ id: rid(), at: Date.now() }, item));
  while (m.items.length > MAIL_MAX) m.items.shift();
  return m;
});
var sumOf = (id) => val(S().rows, "s:" + id);
async function effInv(id) {
  const { rows, soc } = S(), [inv, gone, mail] = await Promise.all([val(rows, "i:" + id), val(soc, "g:" + id), val(soc, "m:" + id)]);
  const g = new Set(gone && gone.g || []), map = /* @__PURE__ */ new Map();
  (inv && inv.cards || []).forEach((c) => {
    if (!g.has(c.u)) map.set(c.u, c);
  });
  (mail && mail.items || []).forEach((it) => {
    if (it.t === "deliver") (it.cards || []).forEach((c) => map.set(c.u, c));
    else if (it.t === "revoke") (it.uids || []).forEach((u) => map.delete(u));
  });
  return map;
}
async function pool(items, n, fn) {
  const out = [];
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) {
      const k = i++;
      out[k] = await fn(items[k], k);
    }
  }));
  return out;
}
var R = {};
R.ping = async () => {
  await secret();
  return { ok: true, v: V, now: Date.now() };
};
R.avail = async (b) => {
  if (!nameOk(b.name)) return { ok: true, free: false, why: "bad" };
  const lc = lower(b.name);
  if (BAD.some((w) => lc.includes(w))) return { ok: true, free: false, why: "bad" };
  const n = await val(S().users, "n:" + lc);
  return { ok: true, free: !(n && await val(S().users, "u:" + n.id)) };
};
R.signup = async (b, ctx) => {
  const name = b.name, pw = b.password;
  if (!nameOk(name)) throw new Err("bad_name", "Use 3 to 16 letters, numbers or underscores.");
  const lc = lower(name);
  if (BAD.some((w) => lc.includes(w))) throw new Err("bad_name", "That name is not allowed. Try another.");
  if (typeof pw !== "string" || pw.length < 6 || pw.length > 64) throw new Err("bad_pw", "Your password needs 6 to 64 characters.");
  if (lower(pw) === lc) throw new Err("bad_pw", "Your password cannot be your username.");
  const { users, meta, rows } = S(), ip = ctx && ctx.ip ? crypto.createHash("sha256").update(String(ctx.ip)).digest("hex").slice(0, 20) : null;
  if (ip) {
    const rl = await val(meta, "rl:" + ip), now = Date.now();
    if (rl && now - rl.t < 36e5 && rl.n >= 10) throw new Err("slow", "Too many new accounts from this network. Try again in an hour.", 429);
    await meta.setJSON("rl:" + ip, rl && now - rl.t < 36e5 ? { n: rl.n + 1, t: rl.t } : { n: 1, t: now });
  }
  const id = rid(), claim = await users.setJSON("n:" + lc, { id }, { onlyIfNew: true });
  if (!claim.modified) {
    const old = await val(users, "n:" + lc);
    if (old && await val(users, "u:" + old.id)) throw new Err("taken", "That username is taken. Try another.");
    await users.setJSON("n:" + lc, { id });
  }
  const salt = crypto.randomBytes(16).toString("hex"), u = { id, name, lc, salt, hash: await scrypt(pw, salt), joined: Date.now(), tv: 0, fails: 0, lock: 0 };
  await users.setJSON("u:" + id, u);
  await rows.setJSON("s:" + id, { id, n: name, c: "", cr: null, o: 0, e: 0, rk: "", p: 0, w: 0, tr: 0, cd: 0, b: 0, j: u.joined, a: u.joined });
  return { ok: true, token: await mkToken(u), me: pub(u) };
};
R.login = async (b) => {
  const { users } = S(), bad = new Err("bad_login", "That username or password is not right.", 401);
  if (!nameOk(b.name) || typeof b.password !== "string") throw bad;
  const n = await val(users, "n:" + lower(b.name));
  if (!n) {
    await scrypt(String(b.password).slice(0, 64), "x");
    throw bad;
  }
  const u = await val(users, "u:" + n.id);
  if (!u) throw bad;
  if (u.lock > Date.now()) throw new Err("locked", "Too many wrong passwords. Try again in " + Math.max(1, Math.ceil((u.lock - Date.now()) / 6e4)) + " minutes.", 429);
  if (!eq(await scrypt(String(b.password).slice(0, 64), u.salt), u.hash)) {
    await upd(users, "u:" + u.id, (x) => {
      x.fails = (x.fails | 0) + 1;
      if (x.fails >= 7) {
        x.lock = Date.now() + 10 * 6e4;
        x.fails = 0;
      }
      return x;
    });
    throw bad;
  }
  if (u.fails) await upd(users, "u:" + u.id, (x) => {
    x.fails = 0;
    x.lock = 0;
    return x;
  });
  return { ok: true, token: await mkToken(u), me: pub(u) };
};
R.me = async (b, ctx, u) => {
  const [f, x, s] = await Promise.all([getSoc(u.id), getX(u.id), sumOf(u.id)]);
  return { ok: true, me: pub(u), sum: s, counts: { inc: f.i.length, friends: f.f.length, tin: x.i.length, tout: x.o.length }, now: Date.now() };
};
R.pw = async (b, ctx, u) => {
  if (typeof b.old !== "string" || typeof b.new !== "string") throw new Err("bad_pw", "Type your old and new password.");
  if (b.new.length < 6 || b.new.length > 64) throw new Err("bad_pw", "Your new password needs 6 to 64 characters.");
  if (!eq(await scrypt(b.old.slice(0, 64), u.salt), u.hash)) throw new Err("bad_login", "Your old password is not right.", 401);
  const salt = crypto.randomBytes(16).toString("hex"), hash = await scrypt(b.new, salt);
  const nu = await upd(S().users, "u:" + u.id, (x) => Object.assign(x, { salt, hash, tv: (x.tv | 0) + 1 }));
  return { ok: true, token: await mkToken(nu) };
};
R.del = async (b, ctx, u) => {
  if (typeof b.password !== "string" || !eq(await scrypt(b.password.slice(0, 64), u.salt), u.hash)) throw new Err("bad_login", "That password is not right.", 401);
  const { users, rows, soc, trd, own } = S(), x = await getX(u.id);
  for (const tid of x.i) {
    try {
      await settle(tid, "declined", u.id, true);
    } catch (e) {
    }
  }
  for (const tid of x.o) {
    try {
      await settle(tid, "cancelled", u.id, true);
    } catch (e) {
    }
  }
  const f = await getSoc(u.id);
  for (const o of f.f.concat(f.i, f.o)) await upd(soc, "f:" + o, (d) => {
    d.f = dropFrom(d.f, u.id);
    d.i = dropFrom(d.i, u.id);
    d.o = dropFrom(d.o, u.id);
    return d;
  }).catch(() => {
  });
  const inv = await val(rows, "i:" + u.id);
  for (const c of inv && inv.cards || []) await own.delete("o:" + c.u).catch(() => {
  });
  await Promise.all([users.delete("u:" + u.id), users.delete("n:" + u.lc), rows.delete("s:" + u.id), rows.delete("r:" + u.id), rows.delete("i:" + u.id), soc.delete("f:" + u.id), soc.delete("m:" + u.id), soc.delete("g:" + u.id), trd.delete("x:" + u.id)]);
  return { ok: true };
};
R.sync = async (b, ctx, u) => {
  const { rows, soc } = S(), now = Date.now(), snap = b.snap && typeof b.snap === "object" ? b.snap : null;
  if (snap) {
    const prev = await val(rows, "s:" + u.id) || {}, a = snap.acct || {}, k = snap.club || null, st = a.stats || {};
    const play = Math.max(prev.p | 0, NUM(a.play, 0, 6e6));
    const rk = a.ranked && typeof a.ranked === "object" ? a.ranked : {}, ladders = {};
    ["n", "h", "i"].forEach((l) => {
      const o = rk[l] || {};
      ladders[l] = { elo: NUM(o.elo, 0, 9999), w: NUM(o.w, 0, 99999), d: NUM(o.d, 0, 99999), l: NUM(o.l, 0, 99999), best: STR(o.best, 22) };
    });
    const e = Math.max(ladders.n.elo, ladders.h.elo, ladders.i.elo), ek = ["n", "h", "i"].find((l) => ladders[l].elo === e) || "n";
    const s = Object.assign({}, prev, { id: u.id, n: u.name, p: play, w: NUM(st.w, 0, 999999), tr: NUM(st.tr, 0, 99999), e, rk: STR(rk[ek] && rk[ek].tier, 24) || (prev.rk || ""), j: u.joined, a: now });
    const det = await val(rows, "r:" + u.id) || {};
    det.id = u.id;
    det.n = u.name;
    det.upd = now;
    det.joined = u.joined;
    det.mgr = STR(a.mgr, 20);
    det.stats = { w: NUM(st.w, 0, 999999), d: NUM(st.d, 0, 999999), l: NUM(st.l, 0, 999999), gf: NUM(st.gf, 0, 9999999), ga: NUM(st.ga, 0, 9999999), seasons: NUM(st.seasons, 0, 99999), promos: NUM(st.promos, 0, 9999), lg: NUM(st.lg, 0, 9999), cup: NUM(st.cup, 0, 9999), cont: NUM(st.cont, 0, 9999), icons: NUM(st.icons, 0, 99999), packs: NUM(st.packs, 0, 999999), ws: NUM(st.ws, 0, 9999) };
    det.ranked = ladders;
    det.play = play;
    if (k) {
      const rt = k.rat || {};
      det.club = STR(k.name, 24);
      det.crest = cleanCrest(k.crest);
      det.nat = STR(k.nat, 4);
      det.form = STR(k.form, 8);
      det.mode = STR(k.mode, 8);
      det.season = NUM(k.season, 0, 9999);
      det.rat = { ovr: NUM(rt.ovr, 0, 199), att: NUM(rt.att, 0, 199), mid: NUM(rt.mid, 0, 199), def: NUM(rt.def, 0, 199), gk: NUM(rt.gk, 0, 199), chem: NUM(rt.chem, 0, 100) };
      det.xi = (Array.isArray(k.xi) ? k.xi : []).slice(0, 11).map((c) => cleanCard(Object.assign({}, c, { u: void 0 }), 200));
      while (det.xi.length < 11) det.xi.push(null);
      det.top = (Array.isArray(k.top) ? k.top : []).slice(0, 14).map((c) => cleanCard(Object.assign({}, c, { u: void 0 }), 200)).filter(Boolean);
      det.cards = NUM(k.cards, 0, 99999);
      det.coins = NUM(k.coins, 0, 9e12);
      const best = det.top.reduce((m, c) => c.ovr > m ? c.ovr : m, 0);
      Object.assign(s, { c: det.club, cr: det.crest, o: det.rat.ovr, cd: det.cards, b: best || s.b | 0, f: det.form });
    }
    await Promise.all([rows.setJSON("s:" + u.id, s), rows.setJSON("r:" + u.id, det)]);
  } else await upd(rows, "s:" + u.id, (s) => {
    if (!s) return void 0;
    s.a = now;
    return s;
  });
  let needInv = false, blockedList = [];
  const stored = await val(rows, "i:" + u.id);
  if (b.inv && Array.isArray(b.inv.cards)) {
    const gone = new Set((await val(soc, "g:" + u.id) || { g: [] }).g), seen = /* @__PURE__ */ new Set(), keep = [];
    for (const raw of b.inv.cards.slice(0, MAX_CARDS)) {
      const c = cleanCard(raw);
      if (!c || !c.u || seen.has(c.u) || c.dev || gone.has(c.u)) continue;
      seen.add(c.u);
      keep.push(c);
    }
    const prevU = new Set((stored && stored.cards || []).map((c) => c.u)), fresh = keep.filter((c) => !prevU.has(c.u)), blocked = /* @__PURE__ */ new Set();
    await pool(fresh, 16, async (c) => {
      const w = await S().own.setJSON("o:" + c.u, { a: u.id }, { onlyIfNew: true });
      if (!w.modified) {
        const o = await val(S().own, "o:" + c.u);
        if (o && o.a !== u.id) {
          if ((await effInv(o.a)).has(c.u)) blocked.add(c.u);
          else await S().own.setJSON("o:" + c.u, { a: u.id });
        }
      }
    });
    const cards = keep.filter((c) => !blocked.has(c.u));
    await rows.setJSON("i:" + u.id, { h: STR(b.inv.h, 24), cards, at: now });
    if (blocked.size) blockedList = [...blocked];
  } else if (b.ih !== void 0 && (!stored || stored.h !== STR(b.ih, 24))) needInv = true;
  const mailDoc = await val(soc, "m:" + u.id);
  if (Array.isArray(b.ack) && b.ack.length && mailDoc) {
    const ack = new Set(b.ack.slice(0, 80).map((x2) => STR(x2, 24)));
    await upd(soc, "m:" + u.id, (m) => {
      if (!m) return void 0;
      const n = m.items.filter((it) => !ack.has(it.id));
      if (n.length === m.items.length) return void 0;
      m.items = n;
      return m;
    });
  }
  const [mail, x, f] = await Promise.all([val(soc, "m:" + u.id), getX(u.id), getSoc(u.id)]);
  return { ok: true, needInv, blocked: blockedList, mail: mail && mail.items || [], locked: Object.keys(x.lk || {}), counts: { inc: f.i.length, friends: f.f.length, tin: x.i.length, tout: x.o.length }, now };
};
var _lb = null;
async function allSums() {
  const { rows, meta } = S(), now = Date.now();
  if (_lb && now - _lb.at < 8e3) return _lb.rows;
  let c = _lb || await val(meta, "lb") || { at: 0, rows: {}, tags: {} };
  if (now - c.at < 12e3 && Object.keys(c.rows).length) {
    _lb = c;
    return c.rows;
  }
  const list = (await rows.list({ prefix: "s:" })).blobs, tags = {}, out = {}, todo = [];
  list.forEach((b) => {
    const id = b.key.slice(2);
    tags[id] = b.etag;
    if (c.tags && c.tags[id] === b.etag && c.rows[id]) out[id] = c.rows[id];
    else todo.push(b.key);
  });
  await pool(todo, 20, async (k) => {
    const s = await val(rows, k);
    if (s) out[s.id] = s;
  });
  c = { at: now, rows: out, tags };
  _lb = c;
  await meta.setJSON("lb", c).catch(() => {
  });
  return out;
}
var BOARDS = { play: "p", ovr: "o", elo: "e", wins: "w", titles: "tr", cards: "cd", best: "b" };
var sortRows = (m, k) => {
  const f = BOARDS[k] || "o";
  return Object.values(m).filter((s) => s.o || s.p || s.e || s.w).sort((a, b) => (b[f] | 0) - (a[f] | 0) || (a.j | 0) - (b.j | 0));
};
R.board = async (b, ctx, u) => {
  const all = await allSums(), k = BOARDS[b.k] ? b.k : "ovr", list = sortRows(all, k), n = NUM(b.n, 1, 100, 50), mine = list.findIndex((s) => s.id === u.id);
  return { ok: true, k, total: list.length, rows: list.slice(0, n), me: { rank: mine + 1, row: all[u.id] || null }, at: Date.now() };
};
R.dir = async (b, ctx, u) => {
  const all = await allSums(), k = BOARDS[b.k] ? b.k : "ovr", q = lower(STR(b.q, 20)).trim(), off = NUM(b.off, 0, 1e5), n = NUM(b.n, 1, 40, 24);
  let list = Object.values(all);
  if (q) list = list.filter((s) => lower(s.n).includes(q) || lower(s.c || "").includes(q));
  const f = BOARDS[k];
  list.sort((a, b2) => (b2[f] | 0) - (a[f] | 0) || lower(a.n).localeCompare(lower(b2.n)));
  const f2 = await getSoc(u.id);
  return { ok: true, total: list.length, rows: list.slice(off, off + n).map((s) => Object.assign({}, s, { rel: relOf(f2, u.id, s.id) })), now: Date.now() };
};
var relOf = (f, me, id) => id === me ? "self" : f.f.includes(id) ? "friend" : f.o.includes(id) ? "out" : f.i.includes(id) ? "inc" : "none";
R.prof = async (b, ctx, u) => {
  const id = STR(b.id, 24), [s, d, f] = await Promise.all([sumOf(id), val(S().rows, "r:" + id), getSoc(u.id)]);
  if (!s) throw new Err("nouser", "That account does not exist any more.", 404);
  return { ok: true, sum: s, prof: d || {}, rel: relOf(f, u.id, id), now: Date.now() };
};
R.theirs = async (b, ctx, u) => {
  const id = STR(b.id, 24), f = await getSoc(u.id);
  if (!f.f.includes(id)) throw new Err("notfriend", "You can only trade with friends.", 403);
  const m = await effInv(id), x = await getX(id), lk = x.lk || {};
  return { ok: true, cards: [...m.values()].filter((c) => !lk[c.u]).sort((a, c) => c.ovr - a.ovr), now: Date.now() };
};
R.bind = async (b, ctx, u) => {
  const x = await getX(u.id);
  if (x.o.length) throw new Err("busy", "Cancel your open trade offers first, then switch your online club.");
  await S().rows.setJSON("i:" + u.id, { h: "", cards: [], at: Date.now() });
  return { ok: true };
};
R.mine = async (b, ctx, u) => ({ ok: true, cards: [...(await effInv(u.id)).values()] });
R.fr = async (b, ctx, u) => {
  const f = await getSoc(u.id), all = await allSums(), g = (id) => all[id] || null;
  return { ok: true, friends: f.f.map(g).filter(Boolean), inc: f.i.map(g).filter(Boolean), out: f.o.map(g).filter(Boolean), now: Date.now() };
};
async function resolveTarget(b) {
  if (b.id) {
    const s = await sumOf(STR(b.id, 24));
    if (s) return s.id;
  }
  if (b.name && nameOk(b.name)) {
    const n = await val(S().users, "n:" + lower(b.name));
    if (n) return n.id;
  }
  throw new Err("nouser", "Nobody has that username.", 404);
}
R.fr_add = async (b, ctx, u) => {
  const id = await resolveTarget(b), { soc } = S();
  if (id === u.id) throw new Err("self", "That is you.");
  const mine = await getSoc(u.id);
  if (mine.f.includes(id)) throw new Err("already", "You are already friends.");
  if (mine.i.includes(id)) return R.fr_ok({ id }, ctx, u);
  if (mine.f.length >= MAX_FRIENDS) throw new Err("full", "Your friends list is full.");
  if (mine.o.includes(id)) throw new Err("sent", "You already asked them.");
  const theirs = await getSoc(id);
  if (theirs.i.length >= MAX_PENDING) throw new Err("full", "They have too many requests waiting.");
  await upd(soc, "f:" + u.id, (d) => {
    d.o = addTo(d.o, id, MAX_PENDING);
    return d;
  }, emptySoc);
  await upd(soc, "f:" + id, (d) => {
    d.i = addTo(d.i, u.id, MAX_PENDING);
    return d;
  }, emptySoc);
  return { ok: true, rel: "out" };
};
R.fr_ok = async (b, ctx, u) => {
  const id = STR(b.id, 24), { soc } = S(), mine = await getSoc(u.id);
  if (!mine.i.includes(id)) throw new Err("none", "That request is gone.");
  if (mine.f.length >= MAX_FRIENDS) throw new Err("full", "Your friends list is full.");
  await upd(soc, "f:" + u.id, (d) => {
    d.i = dropFrom(d.i, id);
    d.o = dropFrom(d.o, id);
    d.f = addTo(d.f, id, MAX_FRIENDS);
    return d;
  }, emptySoc);
  await upd(soc, "f:" + id, (d) => {
    d.o = dropFrom(d.o, u.id);
    d.i = dropFrom(d.i, u.id);
    d.f = addTo(d.f, u.id, MAX_FRIENDS);
    return d;
  }, emptySoc);
  return { ok: true, rel: "friend" };
};
R.fr_no = async (b, ctx, u) => {
  const id = STR(b.id, 24), { soc } = S();
  await upd(soc, "f:" + u.id, (d) => {
    d.i = dropFrom(d.i, id);
    d.o = dropFrom(d.o, id);
    d.f = dropFrom(d.f, id);
    return d;
  }, emptySoc);
  await upd(soc, "f:" + id, (d) => {
    d.i = dropFrom(d.i, u.id);
    d.o = dropFrom(d.o, u.id);
    d.f = dropFrom(d.f, u.id);
    return d;
  }, emptySoc);
  return { ok: true, rel: "none" };
};
var brief = (c) => ({ u: c.u, first: c.first, last: c.last, ovr: c.ovr, pos: c.pos });
async function tradeView(t, me) {
  return { id: t.id, st: t.st, from: t.from, to: t.to, fn: t.fn, tn: t.tn, give: t.give, want: t.want, note: t.note, at: t.at, up: t.up, mine: t.from === me };
}
R.tr_list = async (b, ctx, u) => {
  const x = await getX(u.id), { trd } = S(), now = Date.now(), ids = x.i.concat(x.o), out = { in: [], out: [], hist: x.h || [] };
  const ts = await pool(ids, 10, (tid) => val(trd, "t:" + tid));
  for (const t of ts) {
    if (!t) continue;
    if (t.st === "open" && now - t.at > OFFER_LIFE) {
      try {
        await settle(t.id, "expired", u.id, true);
      } catch (e) {
      }
      continue;
    }
    (t.to === u.id ? out.in : out.out).push(await tradeView(t, u.id));
  }
  out.in.sort((a, c) => c.at - a.at);
  out.out.sort((a, c) => c.at - a.at);
  return { ok: true, in: out.in, out: out.out, hist: out.hist, now };
};
R.tr_new = async (b, ctx, u) => {
  const to = STR(b.to, 24), give = [...new Set((Array.isArray(b.give) ? b.give : []).filter(UID))], want = [...new Set((Array.isArray(b.want) ? b.want : []).filter(UID))], note = STR(b.note, 90);
  if (!give.length || !want.length) throw new Err("empty", "Pick at least one card from each side.");
  if (give.length > MAX_SIDE || want.length > MAX_SIDE) throw new Err("big", "A trade can have up to " + MAX_SIDE + " cards each way.");
  const mine = await getSoc(u.id);
  if (!mine.f.includes(to)) throw new Err("notfriend", "You can only trade with friends.", 403);
  const [mx, tx, theirU] = await Promise.all([getX(u.id), getX(to), val(S().users, "u:" + to)]);
  if (!theirU) throw new Err("nouser", "That account does not exist any more.", 404);
  if (mx.o.length >= MAX_OUT) throw new Err("limit", "You already have " + MAX_OUT + " offers waiting. Cancel one first.");
  if (tx.i.length >= MAX_IN) throw new Err("limit", "They have too many offers waiting.");
  const [mi, ti] = await Promise.all([effInv(u.id), effInv(to)]), G = [], W = [];
  for (const g of give) {
    const c = mi.get(g);
    if (!c) throw new Err("missing", "One of your cards is not available any more. Refresh and try again.");
    if (mx.lk[g]) throw new Err("locked", "One of those cards is already in another offer.");
    G.push(c);
  }
  for (const w of want) {
    const c = ti.get(w);
    if (!c) throw new Err("missing", "One of their cards is not available any more.");
    W.push(c);
  }
  const t = { id: rid(), st: "open", from: u.id, to, fn: u.name, tn: theirU.name, give: G, want: W, note, at: Date.now(), up: Date.now() };
  await S().trd.setJSON("t:" + t.id, t, { onlyIfNew: true });
  await upd(S().trd, "x:" + u.id, (d) => {
    d.o = addTo(d.o, t.id, 40);
    give.forEach((g) => {
      d.lk[g] = t.id;
    });
    return d;
  }, emptyX);
  await upd(S().trd, "x:" + to, (d) => {
    d.i = addTo(d.i, t.id, 60);
    return d;
  }, emptyX);
  return { ok: true, trade: await tradeView(t, u.id), locked: give };
};
async function settle(tid, how, by, quiet) {
  const { trd } = S(), d = await getDoc(trd, "t:" + tid);
  if (!d) throw new Err("none", "That offer is gone.", 404);
  const t = d.v;
  if (t.st !== "open") throw new Err("closed", "That offer is already closed.");
  if (how === "cancelled" && t.from !== by) throw new Err("forbidden", "Only the sender can take an offer back.", 403);
  if (how === "declined" && t.to !== by) throw new Err("forbidden", "Only the receiver can decline an offer.", 403);
  const w = await trd.setJSON("t:" + tid, Object.assign({}, t, { st: how, up: Date.now() }), { onlyIfMatch: d.etag });
  if (!w.modified) throw new Err("closed", "That offer just changed. Refresh.");
  await release(t, how, quiet);
  return t;
}
async function release(t, how, quiet) {
  const { trd } = S(), h = (id) => ({ id: t.id, st: how, w: id === t.from ? t.tn : t.fn, give: t.give.map(brief), want: t.want.map(brief), out: id === t.from, at: Date.now() });
  await upd(trd, "x:" + t.from, (d) => {
    d.o = dropFrom(d.o, t.id);
    t.give.forEach((c) => {
      if (d.lk[c.u] === t.id) delete d.lk[c.u];
    });
    d.h.unshift(h(t.from));
    d.h = d.h.slice(0, HIST_MAX);
    return d;
  }, emptyX);
  await upd(trd, "x:" + t.to, (d) => {
    d.i = dropFrom(d.i, t.id);
    d.h.unshift(h(t.to));
    d.h = d.h.slice(0, HIST_MAX);
    return d;
  }, emptyX);
  if (!quiet && how === "declined") await mailAdd(t.from, { t: "info", msg: t.tn + " declined your trade offer." });
}
R.tr_no = async (b, ctx, u) => {
  await settle(STR(b.tid, 24), "declined", u.id);
  return { ok: true };
};
R.tr_x = async (b, ctx, u) => {
  const t = await settle(STR(b.tid, 24), "cancelled", u.id);
  return { ok: true, locked: t.give.map((c) => c.u) };
};
R.tr_ok = async (b, ctx, u) => {
  const tid = STR(b.tid, 24), { trd, soc, own } = S(), d = await getDoc(trd, "t:" + tid);
  if (!d) throw new Err("none", "That offer is gone.", 404);
  const t = d.v;
  if (t.to !== u.id) throw new Err("forbidden", "That offer is not for you.", 403);
  if (t.st !== "open") throw new Err("closed", "That offer is already closed.");
  if (Date.now() - t.at > OFFER_LIFE) {
    await settle(tid, "expired", u.id, true).catch(() => {
    });
    throw new Err("expired", "That offer ran out.");
  }
  const [si, ri] = await Promise.all([effInv(t.from), effInv(t.to)]);
  const lost = (m2, cards) => cards.some((c) => !m2.has(c.u));
  if (lost(si, t.give)) {
    await settle(tid, "cancelled", t.from, true).catch(() => {
    });
    throw new Err("missing", t.fn + " no longer has all of those cards. The offer was cancelled.");
  }
  if (lost(ri, t.want)) throw new Err("missing", "You no longer have all of the cards they asked for. Sync the game and check your squad.");
  const w = await trd.setJSON("t:" + tid, Object.assign({}, t, { st: "accepted", up: Date.now() }), { onlyIfMatch: d.etag });
  if (!w.modified) throw new Err("closed", "That offer just changed. Refresh.");
  const giveU = t.give.map((c) => c.u), wantU = t.want.map((c) => c.u);
  for (const [id, out, inn, cardsIn, other] of [[t.from, giveU, wantU, t.want, t.tn], [t.to, wantU, giveU, t.give, t.fn]]) {
    await upd(soc, "g:" + id, (g) => {
      g = g || { g: [] };
      out.forEach((x) => addTo(g.g, x, GONE_MAX));
      g.g = g.g.filter((x) => !inn.includes(x));
      return g;
    });
    await mailAdd(id, { t: "revoke", uids: out, tid });
    await mailAdd(id, { t: "deliver", cards: cardsIn, tid, from: other });
  }
  for (const c of t.give) await own.setJSON("o:" + c.u, { a: t.to });
  for (const c of t.want) await own.setJSON("o:" + c.u, { a: t.from });
  await release(t, "accepted", true);
  const m = await val(soc, "m:" + u.id);
  return { ok: true, mail: m && m.items || [] };
};
async function handler(req, context) {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });
  if (req.method !== "POST") return J({ ok: false, err: "method", msg: "POST only." }, 405);
  let b;
  try {
    b = await req.json();
  } catch (e) {
    return J({ ok: false, err: "json", msg: "Bad request." }, 400);
  }
  const fn = b && typeof b.r === "string" && Object.prototype.hasOwnProperty.call(R, b.r) ? R[b.r] : null;
  if (!fn) return J({ ok: false, err: "route", msg: "Unknown request." }, 404);
  try {
    const open = b.r === "ping" || b.r === "signup" || b.r === "login" || b.r === "avail";
    const u = open ? null : await authUser(b.token);
    return J(await fn(b, context, u));
  } catch (e) {
    if (e instanceof Err) return J({ ok: false, err: e.code, msg: e.message }, e.status);
    const text = String(e && e.message || e);
    if (/blobs|environment has not been configured|MissingBlobs/i.test(text)) return J({ ok: false, err: "store", msg: "The online storage is not switched on for this site." }, 503);
    console.error("mfc api", b && b.r, text);
    return J({ ok: false, err: "server", msg: "Something went wrong on the server. Try again." }, 500);
  }
}
export {
  handler as default
};
